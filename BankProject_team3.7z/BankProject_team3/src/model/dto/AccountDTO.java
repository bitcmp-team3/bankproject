package model.dto;

import java.io.Serializable;

public class AccountDTO implements Serializable {
 
    private static final long serialVersionUID = 1L;
	
	private int userNo;
	private String accNo;
	
	public AccountDTO() {
		
	}


	public AccountDTO(String accNo) {
		this.accNo = accNo;
	}


	public AccountDTO(int userNo, String accNo) {
		this.userNo = userNo;
		this.accNo = accNo;
	}
	
	
	
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	
	@Override
	public String toString() {
		return "AccountDTO [userNo=" + userNo + ", accNo=" + accNo + "]";
	}


	
	
	
	

}