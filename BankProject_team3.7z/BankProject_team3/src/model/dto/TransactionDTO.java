package model.dto;

import java.sql.Date;

public class TransactionDTO {
	
		private String userNo;
		private String accNo;
		private int amount;
		private String type;
		private int deposit;
		private int withdraw;
		
		public TransactionDTO() {
			
				
		}
		
		
		public TransactionDTO(String type, int amount, int deposit, int withdraw) {
			this.type = type;
			this.amount = amount;
			this.deposit = deposit;
			this.withdraw = withdraw;
		}


		public String getType() {
			return type;
		}


		public void setType(String type) {
			this.type = type;
		}


		public String getUserNo() {
			return userNo;
		}
		public void setUserNo(String userNo) {
			this.userNo = userNo;
		}
		public String getAccNo() {
			return accNo;
		}
		public void setAccNo(String accNo) {
			this.accNo = accNo;
		}
		public int getAmount() {
			return amount;
		}
		public void setAmount(int amount) {
			this.amount = amount;
		}
		
		public int getDeposit() {
			return deposit;
		}
		public void setDeposit(int deposit) {
			this.deposit = deposit;
		}
		public int getWithdraw() {
			return withdraw;
		}
		public void setWithdraw(int withdraw) {
			this.withdraw = withdraw;
		}
		@Override
		public String toString() {
			return "TransactionBean [userNo=" + userNo + ", accNo=" + accNo + ", amount=" + amount + ", type=" + type
					+ ", deposit=" + deposit + ", withdraw=" + withdraw + "]";
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((accNo == null) ? 0 : accNo.hashCode());
			result = prime * result + amount;
			result = prime * result + (( type== null) ? 0 : type.hashCode());
			result = prime * result + deposit;
			result = prime * result + ((userNo == null) ? 0 : userNo.hashCode());
			result = prime * result + withdraw;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			TransactionDTO other = (TransactionDTO) obj;
			if (accNo == null) {
				if (other.accNo != null)
					return false;
			} else if (!accNo.equals(other.accNo))
				return false;
			if (amount != other.amount)
				return false;
			if (type == null) {
				if (other.type != null)
					return false;
			} else if (!type.equals(other.type))
				return false;
			if (deposit != other.deposit)
				return false;
			if (userNo == null) {
				if (other.userNo != null)
					return false;
			} else if (!userNo.equals(other.userNo))
				return false;
			if (withdraw != other.withdraw)
				return false;
			return true;
		}
}
