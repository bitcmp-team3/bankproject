package model.dto;



public class UserDTO {
	
	private int id;
	private String pw;
	private String name;
	private String birthday;
	private String phoneNo;
	private String addr;
	
	public UserDTO(int id, String pw) {
		
	}

	public UserDTO( int id, String pw, String name, String birthday, String phoneNo, String addr) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.birthday = birthday;
		this.phoneNo = phoneNo;
		this.addr = addr;
	}
	

	public UserDTO() {
		
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}



	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", pw=" + pw + ", name=" + name + ", birthday=" + birthday + ", phoneNo=" + phoneNo
				+ ", addr=" + addr + "]";
	}

	

	
	
	
	
	
}
