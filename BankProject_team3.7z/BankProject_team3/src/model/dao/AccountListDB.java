package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;

import java.sql.Statement;
import java.util.ArrayList;

import model.dto.AccountDTO;



public class AccountListDB {
	
	
	private static String url = "jdbc:mysql://localhost/bank?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static String username = "root";
	private static String password = "1235789Zero@";
	
	public static ArrayList<AccountDTO> select() {
        
        ArrayList<AccountDTO> accs = new ArrayList<AccountDTO>();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
            try (Connection conn = DriverManager.getConnection(url, username, password)){
                  
                Statement statement = conn.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT userNo, accNo FROM transaction");
                while(resultSet.next()){
                      
                    int userNo = resultSet.getInt(1);
                    String accNo = resultSet.getString(2);
                    AccountDTO acc = new AccountDTO(userNo, accNo);
                    
                    accs.add(acc);
                   
                }
            }
        }
        catch(Exception ex){
            System.out.println(ex);
        }
        return accs;
    }

		 
		
		
	
}
