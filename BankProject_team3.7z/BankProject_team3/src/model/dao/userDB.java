package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.dto.UserDTO;

public class userDB {
	private static String url = "jdbc:mysql://localhost/bank?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static String username = "root";
	private static String password = "1235789Zero@";

	public static int insert(UserDTO users) {
         
	        try{
	            Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
	            try (Connection conn = DriverManager.getConnection(url, username, password)){
	                  
	                String sql = "INSERT INTO user ( id, pw, name, birthday, phoneNo, addr) Values (?, ?, ?, ? ,? ,?)";
	                try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
	                	
	                    preparedStatement.setInt(1, users.getId());
	                    preparedStatement.setString(2, users.getPw());
	                    preparedStatement.setString(3, users.getName());
	                    preparedStatement.setString(4, users.getBirthday());
	                    preparedStatement.setString(5, users.getPhoneNo());
	                    preparedStatement.setString(6, users.getAddr());
	                    return  preparedStatement.executeUpdate();
	                }
	            }
	        }
	        catch(Exception ex){
	            System.out.println(ex);
	        }
	        return 0;
	    }
}