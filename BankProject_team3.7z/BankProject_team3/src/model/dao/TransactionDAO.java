package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.dto.TransactionDTO;

public class TransactionDAO {
	private static String url = "jdbc:mysql://localhost/bank?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static String username = "root";
	private static String password = "1235789Zero@";


	public static int update(TransactionDTO transaction) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
			try (Connection conn = DriverManager.getConnection(url, username, password)) {

				String sql = "UPDATE transaction SET amount = ?, deposit = ?, withdraw = ? type = ? WHERE accNo= ?";
				try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
					preparedStatement.setInt(1, transaction.getAmount());
					preparedStatement.setInt(2, transaction.getDeposit());
					preparedStatement.setInt(3, transaction.getWithdraw());
					preparedStatement.setString(4, transaction.getType());
					preparedStatement.setString(5, transaction.getAccNo());

					return preparedStatement.executeUpdate();
				}
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return 0;
	}

	
     
 
}
