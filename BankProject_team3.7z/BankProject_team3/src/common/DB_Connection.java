package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DB_Connection {
	private static DB_Connection instance;
	Connection conn = null;

	public Connection get_connection() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost/bank?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "1235789Zero@");

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return conn;

	}

	public static DB_Connection getInstance() {
		return (instance == null) ? instance = new DB_Connection() : instance;
	}

	private void close() {
		try {
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void finalize() throws Throwable {
		close();
		super.finalize();
	}




	

}
