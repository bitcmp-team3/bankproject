package conntroller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.DB_Connection;
import model.dao.userDB;
import model.dto.UserDTO;

/**
 * Servlet implementation class LoginProccessServlet
 */

public class LoginProccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			int id = Integer.parseInt(request.getParameter("id"));
			String pw = request.getParameter("pw");
			String name = request.getParameter("name");
			String birthday = request.getParameter("birthday");
			String phoneNo = request.getParameter("phoneNo");
			String addr = request.getParameter("addr");
			UserDTO user = new UserDTO( id, pw, name, birthday, phoneNo, addr);
			userDB.insert(user);
			
		} catch (Exception ex) {
			getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}
}
//	 protected void doGet(HttpServletRequest request, HttpServletResponse response) 
//		        throws ServletException, IOException {
//		 
//		        getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
//		    }
//		     
//		    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
//		        throws ServletException, IOException {
//		 
//		        try {
//		        	
//		        	String id = request.getParameter("id").trim();
//		    		String pw = request.getParameter("pw").trim();
//		    		String name = request.getParameter("name").trim();
//		    		String birthday = request.getParameter("birthday");
//		    		String phoneNo = request.getParameter("phoneNo").trim();
//		    		String addr = request.getParameter("addr").trim();
//		            
//		            UserDTO users = new UserDTO( id, pw, name, birthday, phoneNo, addr);
//		            DB_Connection.insert(users);
//		            response.sendRedirect(request.getContextPath()+"/welcome");
//		        }
//		        catch(Exception ex) {
//		             
//		            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response); 
//		        }
//		    }

//	protected void doPost(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		Connection conn = null;
//		PreparedStatement pState = null;
//		ResultSet resultSet = null;
//
//		String id = request.getParameter("id").trim();
//		String pw = request.getParameter("pw").trim();
//		String name = request.getParameter("name").trim();
//		String birthday = request.getParameter("birthday");
//		String phoneNo = request.getParameter("phoneNo").trim();
//		String addr = request.getParameter("addr").trim();
//
//		HttpSession session = null;
//		String nextPage;
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
//			conn = DriverManager.getConnection(
//					"jdbc:mysql://localhost/bank?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
//					"root", "1235789Zero@");
//			String sql = "UPDATE user SET cutNo = ?, id = ?, pw =?, name = ?, birthday = ?, phoneNo = ? addr = ? WHERE cutNo = ?";
//			// 사람들),
//			pState = conn.prepareStatement(sql);
//			pState.setInt(1, 1);
//			pState.setString(2, id);
//			pState.setString(3, pw);
//			pState.setString(4, name);
//			pState.setString(5, birthday);
//			pState.setString(6, phoneNo);
//			pState.setString(7, addr);
//			resultSet = pState.executeQuery();
//
//			if (resultSet.next()) {
//				UserDTO users = new UserDTO();
//				users.setUserNo(resultSet.getInt("userNo"));
//				users.setId(resultSet.getString("id"));
//				users.setPw(resultSet.getString("pw"));
//				users.setName(resultSet.getString("name"));
//				users.setBirthday(resultSet.getString("birthday"));
//				users.setPhoneNo(resultSet.getString("phoneNo"));
//				users.setAddr(resultSet.getString("addr"));
//
//				// sesssion
//
//				session = request.getSession();
//				if (!session.isNew()) {
//					session.invalidate();
//					session = request.getSession(true);
//				}
//				request.setAttribute("users", users);
//				session.setMaxInactiveInterval(60);
//				session.setAttribute("user", users);
//				nextPage = "./welcome";
//				request.getRequestDispatcher(nextPage).forward(request, response);
//			} else {// 암호 아이디가 일치하지 않는다
//				nextPage = "./loginfail";
//				response.sendRedirect(nextPage);
//			}
//
//		} catch (InstantiationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IllegalAccessException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
